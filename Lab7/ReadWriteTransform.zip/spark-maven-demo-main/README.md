# spark-maven-demo
Sample Spark application build with Maven

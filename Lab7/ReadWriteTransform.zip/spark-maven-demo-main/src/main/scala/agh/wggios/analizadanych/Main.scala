package agh.wggios.analizadanych

object Main extends SparkSessionProvider {

  def main(args: Array[String]): Unit = {

  }
}

package agh.wggios.analizadanych.datatransform

import agh.wggios.analizadanych

import scala.io.BufferedSource
import scala.io.Source._

class DataTransform {

  val zrodlo: BufferedSource = scala.io.Source.fromFile("file.txt")
  val linie: String = try zrodlo.mkString
  val transformacja: String = linie.toUpperCase()

}

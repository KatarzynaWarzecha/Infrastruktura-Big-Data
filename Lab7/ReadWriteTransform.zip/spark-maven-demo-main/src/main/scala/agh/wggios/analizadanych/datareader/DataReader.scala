package agh.wggios.analizadanych.datareader

import agh.wggios.analizadanych
import scala.io.Source._

class DataReader {

  val zrodlo = scala.io.Source.fromFile("file.txt")
  val linie = try zrodlo.mkString finally zrodlo.close()
//
//   def readData(): DataFrame = { extends SparkSessionProvider
//     isDataReadable = isDataSchemaReadable()
//
//    if (isDataReadabŁe) returnReadData()
//   }
//
//  def isDataAvai1able(): Boolean
//
//  return false
//
//  def returnReadData()
//
//  Boolean
//  DataFrame
//  spark.read.format(source =
//  val df =
//    path =
//  '
//  return df
//
//  def isDataSchemaReadab1e():
//
//  return true
//  Boolean =Boolean

}

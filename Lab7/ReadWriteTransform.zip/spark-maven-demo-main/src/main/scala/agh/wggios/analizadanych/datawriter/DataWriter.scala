package agh.wggios.analizadanych.datawriter
import java.io.PrintWriter
import scala.io.BufferedSource
import scala.io.Source._
class DataWriter {

  val zrodlo: BufferedSource = scala.io.Source.fromFile("file.txt")
  val linie: String = zrodlo.mkString
  val transformacja: String = linie.toUpperCase()

  val writer = new PrintWriter(linie)
  writer.write(transformacja)
  writer.close()
}
